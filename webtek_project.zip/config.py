DEBUG = True
SQLALCHEMY_DATABASE_URI = 'sqlite:///db.db'
CACHE_TYPE = "null"
